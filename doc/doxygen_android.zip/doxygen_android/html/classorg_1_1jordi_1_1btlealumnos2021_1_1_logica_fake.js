var classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake =
[
    [ "LoginCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_login_callback.html", null ],
    [ "RegistroCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_registro_callback.html", null ],
    [ "ActualizarUsuarioCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_actualizar_usuario_callback.html", null ],
    [ "ResumenUsuarioCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_resumen_usuario_callback.html", null ],
    [ "VincularPlacaCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_vincular_placa_callback.html", null ],
    [ "DesvincularPlacaCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_desvincular_placa_callback.html", null ],
    [ "CallbackJSONArray", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_callback_j_s_o_n_array.html", null ],
    [ "CallbackRecorrido", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_callback_recorrido.html", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_callback_recorrido" ],
    [ "EnviarIncidenciaCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_enviar_incidencia_callback.html", null ],
    [ "ListarIncidenciasCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_listar_incidencias_callback.html", null ],
    [ "actualizarEstadoPlaca", "classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#aac2d0677250d11371ef7a7e390b430d9", null ],
    [ "guardarMedicion", "classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a0ca46d20404e428d976e5e85c1ea03aa", null ],
    [ "obtenerMedidasPorGas", "classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a14b760e57f9238835040fa95e5de80c4", null ],
    [ "obtenerMedidasTodos", "classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a6457e42a2189e48b5fbcacb99bb63a2d", null ]
];