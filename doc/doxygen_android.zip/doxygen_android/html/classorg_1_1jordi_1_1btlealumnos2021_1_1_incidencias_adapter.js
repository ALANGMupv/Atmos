var classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_adapter =
[
    [ "IncidenciasAdapter", "classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_adapter.html#a645f55e771071049570c3feb2448e575", null ]
];