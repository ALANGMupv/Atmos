var classorg_1_1jordi_1_1btlealumnos2021_1_1_user_page_activity =
[
    [ "onActivityResult", "classorg_1_1jordi_1_1btlealumnos2021_1_1_user_page_activity.html#a7beb1ed640cf3dce8f77d92e15f7400b", null ],
    [ "onCreate", "classorg_1_1jordi_1_1btlealumnos2021_1_1_user_page_activity.html#abcf44ea0a7b53c0ecc7762f270b881c5", null ],
    [ "onDestroy", "classorg_1_1jordi_1_1btlealumnos2021_1_1_user_page_activity.html#a1d1c7ff4dd8166c4744a7447349206df", null ],
    [ "onResume", "classorg_1_1jordi_1_1btlealumnos2021_1_1_user_page_activity.html#a0b6355c4a6494b27d43b562bd8e9517b", null ]
];