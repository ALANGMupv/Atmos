var classorg_1_1jordi_1_1btlealumnos2021_1_1_vincular_sensor_activity =
[
    [ "onActivityResult", "classorg_1_1jordi_1_1btlealumnos2021_1_1_vincular_sensor_activity.html#acbb0ea6cdb728f7241c8295cabf888a4", null ]
];