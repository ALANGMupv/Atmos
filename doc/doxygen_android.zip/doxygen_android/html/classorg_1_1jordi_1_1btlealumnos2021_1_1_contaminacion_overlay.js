var classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay =
[
    [ "OnIndiceUpdateListener", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay_1_1_on_indice_update_listener.html", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay_1_1_on_indice_update_listener" ],
    [ "draw", "classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#a184097e0ed5f1aee8eaabe33458f374b", null ],
    [ "setOnIndiceUpdateListener", "classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#aa5cf92d94b43cce97a16db200cfa2b4e", null ],
    [ "setPuntos", "classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#a773fcad3ff67970c6817db6370a2fb78", null ]
];