var classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity =
[
    [ "habilitarToggleContrasena", "classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a431fc555880931154810368e98febd2e", null ],
    [ "setupBottomNav", "classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a4213646bda8062a402d21e9846f8b240", null ],
    [ "setupBottomNav", "classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a260f8eba142bd2f33675fac930ae652e", null ],
    [ "setupHeader", "classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a357a26d6537ace7ecfe87125088d219c", null ]
];