var searchData=
[
  ['serviciodeteccionbeacons_0',['ServicioDeteccionBeacons',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons.html',1,'org::jordi::btlealumnos2021']]],
  ['sesionmanager_1',['SesionManager',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html',1,'org::jordi::btlealumnos2021']]]
];
