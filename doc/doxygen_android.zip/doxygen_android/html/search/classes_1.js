var searchData=
[
  ['callbackjsonarray_0',['CallbackJSONArray',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_callback_j_s_o_n_array.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['callbackrecorrido_1',['CallbackRecorrido',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_callback_recorrido.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['contaminacionoverlay_2',['ContaminacionOverlay',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html',1,'org::jordi::btlealumnos2021']]]
];
