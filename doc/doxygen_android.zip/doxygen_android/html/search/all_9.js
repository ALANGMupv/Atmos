var searchData=
[
  ['java_3a_20clase_20con_20funciones_20auxiliares_20para_20convertir_20entre_20cadenas_20bytes_20enteros_20y_20uuids_20además_20de_20mostrar_20datos_20en_20formato_20texto_20o_20hexadecimal_0',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]]
];
