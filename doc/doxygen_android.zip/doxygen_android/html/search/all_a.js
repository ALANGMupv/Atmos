var searchData=
[
  ['la_20interfaz_0',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['la_20trama_20recibida_1',['además de campos auxiliares como advFlags, companyID o iBeaconType, para facilitar el acceso estructurado a la trama recibida.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html#autotoc_md17',1,'']]],
  ['las_20descargas_20terminen_2',['ESPERAR A QUE TODAS LAS DESCARGAS TERMINEN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md2',1,'']]],
  ['leídas_20en_20sharedpreferences_3',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]],
  ['listarincidenciascallback_4',['ListarIncidenciasCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_listar_incidencias_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['listarincidenciasusuario_5',['listarIncidenciasUsuario',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a97de152a99fb5fb707124093bb0d74ce',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['logicafake_6',['LogicaFake',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html',1,'org::jordi::btlealumnos2021']]],
  ['login_7',['LOGIN',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_login_callback.html#autotoc_md3',1,'']]],
  ['logincallback_8',['LoginCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_login_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['loginservidor_9',['loginServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a480c00432b586558b6dff0b92f7b15f8',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['los_20envía_20al_20servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_10',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]]
];
