var searchData=
[
  ['la_20interfaz_0',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['la_20trama_20recibida_1',['además de campos auxiliares como advFlags, companyID o iBeaconType, para facilitar el acceso estructurado a la trama recibida.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html#autotoc_md17',1,'']]],
  ['las_20descargas_20terminen_2',['ESPERAR A QUE TODAS LAS DESCARGAS TERMINEN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md2',1,'']]],
  ['leídas_20en_20sharedpreferences_3',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]],
  ['login_4',['LOGIN',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_login_callback.html#autotoc_md3',1,'']]],
  ['los_20envía_20al_20servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_5',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]]
];
