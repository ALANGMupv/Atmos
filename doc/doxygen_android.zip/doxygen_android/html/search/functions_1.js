var searchData=
[
  ['cerrarsesion_0',['cerrarSesion',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#af0f7d870b36cf405ab15116a10ffcdda',1,'org::jordi::btlealumnos2021::SesionManager']]]
];
