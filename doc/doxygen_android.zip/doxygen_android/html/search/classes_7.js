var searchData=
[
  ['listarincidenciascallback_0',['ListarIncidenciasCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_listar_incidencias_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['logicafake_1',['LogicaFake',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html',1,'org::jordi::btlealumnos2021']]],
  ['logincallback_2',['LoginCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_login_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]]
];
