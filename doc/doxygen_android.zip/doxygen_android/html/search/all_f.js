var searchData=
[
  ['que_20todas_20las_20descargas_20terminen_0',['ESPERAR A QUE TODAS LAS DESCARGAS TERMINEN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md2',1,'']]]
];
