var searchData=
[
  ['sensores_20de_20esta_20estación_0',['DESCARGA DEL DETALLE DE SENSORES DE ESTA ESTACIÓN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md1',1,'']]],
  ['servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_1',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['sharedpreferences_2',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]],
  ['simple_20de_20notificaciones_20leídas_20en_20sharedpreferences_3',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]]
];
