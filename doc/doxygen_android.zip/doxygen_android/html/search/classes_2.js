var searchData=
[
  ['desvincularplacacallback_0',['DesvincularPlacaCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_desvincular_placa_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]]
];
