var searchData=
[
  ['appfuecerrada_0',['appFueCerrada',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_app_lifecycle_tracker.html#aa1bd8d94355f17d73b95510f373d1f5e',1,'org::jordi::btlealumnos2021::AppLifecycleTracker']]]
];
