var searchData=
[
  ['notificacionatmos_0',['NotificacionAtmos',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificacion_atmos.html',1,'org.jordi.btlealumnos2021.NotificacionAtmos'],['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificacion_atmos.html#a395cbbb1bef476ca0c5ea53c681db60d',1,'org.jordi.btlealumnos2021.NotificacionAtmos.NotificacionAtmos()']]],
  ['notificaciones_20leídas_20en_20sharedpreferences_1',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]]
];
