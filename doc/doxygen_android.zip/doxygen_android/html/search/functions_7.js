var searchData=
[
  ['listarincidenciasusuario_0',['listarIncidenciasUsuario',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a97de152a99fb5fb707124093bb0d74ce',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['loginservidor_1',['loginServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a480c00432b586558b6dff0b92f7b15f8',1,'org::jordi::btlealumnos2021::LogicaFake']]]
];
