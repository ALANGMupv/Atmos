var searchData=
[
  ['bloque_20para_20cálculo_20del_20índice_20de_20calidad_0',['=== FIN BLOQUE PARA CÁLCULO DEL ÍNDICE DE CALIDAD ===========',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#autotoc_md0',1,'']]],
  ['botones_20de_20la_20interfaz_1',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['busca_20uno_20concreto_20parsea_20tramas_20ibeacon_20con_20datos_20de_20co₂_20y_20los_20envía_20al_20servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_2',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['bytes_20enteros_20y_20uuids_20además_20de_20mostrar_20datos_20en_20formato_20texto_20o_20hexadecimal_3',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]]
];
