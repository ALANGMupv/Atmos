var searchData=
[
  ['última_20ciudad_20válida_0',['de índice para evitar mostrar información obsoleta (última ciudad válida).',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_mapas_activity.html#autotoc_md10',1,'']]]
];
