var searchData=
[
  ['vincularplacacallback_0',['VincularPlacaCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_vincular_placa_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['vincularsensoractivity_1',['VincularSensorActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_vincular_sensor_activity.html',1,'org::jordi::btlealumnos2021']]]
];
