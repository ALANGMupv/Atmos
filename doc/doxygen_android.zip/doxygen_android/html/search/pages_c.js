var searchData=
[
  ['notificaciones_20leídas_20en_20sharedpreferences_0',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]]
];
