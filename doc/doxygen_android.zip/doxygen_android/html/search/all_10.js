var searchData=
[
  ['recargargrafica_0',['recargarGrafica',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_grafica_helper.html#a7b839054d6569a986bb03c677953b893',1,'org::jordi::btlealumnos2021::GraficaHelper']]],
  ['recibida_1',['además de campos auxiliares como advFlags, companyID o iBeaconType, para facilitar el acceso estructurado a la trama recibida.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html#autotoc_md17',1,'']]],
  ['registro_2',['REGISTRO',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_registro_callback.html#autotoc_md4',1,'']]],
  ['registroactivity_3',['RegistroActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_registro_activity.html',1,'org::jordi::btlealumnos2021']]],
  ['registrocallback_4',['RegistroCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_registro_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['registroservidor_5',['registroServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a0df835a1089b4d8db20d1e064f1bc79d',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['restablecercontrasenaactivity_6',['RestablecerContrasenaActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_restablecer_contrasena_activity.html',1,'org::jordi::btlealumnos2021']]],
  ['resumen_20usuario_7',['RESUMEN USUARIO',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_resumen_usuario_callback.html#autotoc_md5',1,'']]],
  ['resumen_20usuario_20por_20gas_8',['RESUMEN USUARIO POR GAS',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#autotoc_md6',1,'']]],
  ['resumen7dias_9',['resumen7Dias',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#aaa7a7a54818cf8fb7fc715f46f3a275c',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['resumen8horas_10',['resumen8Horas',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#ab7117d62dacc036e37708f2dfaae00ee',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['resumenusuariocallback_11',['ResumenUsuarioCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_resumen_usuario_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['resumenusuarioporgas_12',['resumenUsuarioPorGas',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#ae238d07376a64e4c52fba4161f405585',1,'org::jordi::btlealumnos2021::LogicaFake']]]
];
