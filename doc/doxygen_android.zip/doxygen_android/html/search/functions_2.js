var searchData=
[
  ['desvincularplacaservidor_0',['desvincularPlacaServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a7c13d0f50ba1fd2937d19a17eb2101e8',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['draw_1',['draw',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#a184097e0ed5f1aee8eaabe33458f374b',1,'org::jordi::btlealumnos2021::ContaminacionOverlay']]]
];
