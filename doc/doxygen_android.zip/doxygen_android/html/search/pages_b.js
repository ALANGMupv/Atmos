var searchData=
[
  ['método_3a_20cerrarsesion_0',['MÉTODO: cerrarSesion',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md16',1,'']]],
  ['método_3a_20guardarsesion_1',['MÉTODO: guardarSesion',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md12',1,'']]],
  ['método_3a_20haysesionactiva_2',['MÉTODO: haySesionActiva',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md15',1,'']]],
  ['método_3a_20obtenersesion_3',['MÉTODO: obtenerSesion',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md13',1,'']]],
  ['manejar_20permisos_20y_20botones_20de_20la_20interfaz_4',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['mostrar_20datos_20en_20formato_20texto_20o_20hexadecimal_5',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]],
  ['mostrar_20información_20obsoleta_20última_20ciudad_20válida_6',['de índice para evitar mostrar información obsoleta (última ciudad válida).',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_mapas_activity.html#autotoc_md10',1,'']]],
  ['muestra_20información_20de_20dispositivos_20o_20busca_20uno_20concreto_20parsea_20tramas_20ibeacon_20con_20datos_20de_20co₂_20y_20los_20envía_20al_20servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_7',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]]
];
