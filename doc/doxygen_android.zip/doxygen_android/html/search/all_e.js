var searchData=
[
  ['paginainicio_0',['PaginaInicio',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_pagina_inicio.html',1,'org::jordi::btlealumnos2021']]],
  ['pantallas_1',['Compatibles con EditarPerfil y otras pantallas',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md14',1,'']]],
  ['para_20cálculo_20del_20índice_20de_20calidad_2',['=== FIN BLOQUE PARA CÁLCULO DEL ÍNDICE DE CALIDAD ===========',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#autotoc_md0',1,'']]],
  ['para_20convertir_20entre_20cadenas_20bytes_20enteros_20y_20uuids_20además_20de_20mostrar_20datos_20en_20formato_20texto_20o_20hexadecimal_3',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]],
  ['para_20evitar_20mostrar_20información_20obsoleta_20última_20ciudad_20válida_4',['de índice para evitar mostrar información obsoleta (última ciudad válida).',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_mapas_activity.html#autotoc_md10',1,'']]],
  ['para_20facilitar_20el_20acceso_20estructurado_20a_20la_20trama_20recibida_5',['además de campos auxiliares como advFlags, companyID o iBeaconType, para facilitar el acceso estructurado a la trama recibida.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html#autotoc_md17',1,'']]],
  ['parsea_20tramas_20ibeacon_20con_20datos_20de_20co₂_20y_20los_20envía_20al_20servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_6',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['perfilactivity_7',['PerfilActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_perfil_activity.html',1,'org::jordi::btlealumnos2021']]],
  ['permisos_20y_20botones_20de_20la_20interfaz_8',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['persistencia_20simple_20de_20notificaciones_20leídas_20en_20sharedpreferences_9',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]],
  ['placa_20a_20usuario_10',['VINCULAR PLACA A USUARIO',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_vincular_placa_callback.html#autotoc_md7',1,'']]],
  ['placa_20de_20usuario_11',['DESVINCULAR PLACA DE USUARIO',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_desvincular_placa_callback.html#autotoc_md8',1,'']]],
  ['por_20gas_12',['RESUMEN USUARIO POR GAS',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#autotoc_md6',1,'']]],
  ['preferencias_13',['Preferencias',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_preferencias.html',1,'org::jordi::btlealumnos2021']]],
  ['privacidadactivity_14',['PrivacidadActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_privacidad_activity.html',1,'org::jordi::btlealumnos2021']]]
];
