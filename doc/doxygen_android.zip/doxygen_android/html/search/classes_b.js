var searchData=
[
  ['paginainicio_0',['PaginaInicio',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_pagina_inicio.html',1,'org::jordi::btlealumnos2021']]],
  ['perfilactivity_1',['PerfilActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_perfil_activity.html',1,'org::jordi::btlealumnos2021']]],
  ['preferencias_2',['Preferencias',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_preferencias.html',1,'org::jordi::btlealumnos2021']]],
  ['privacidadactivity_3',['PrivacidadActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_privacidad_activity.html',1,'org::jordi::btlealumnos2021']]]
];
