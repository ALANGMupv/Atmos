var searchData=
[
  ['recibida_0',['además de campos auxiliares como advFlags, companyID o iBeaconType, para facilitar el acceso estructurado a la trama recibida.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html#autotoc_md17',1,'']]],
  ['registro_1',['REGISTRO',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_registro_callback.html#autotoc_md4',1,'']]],
  ['resumen_20usuario_2',['RESUMEN USUARIO',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_resumen_usuario_callback.html#autotoc_md5',1,'']]],
  ['resumen_20usuario_20por_20gas_3',['RESUMEN USUARIO POR GAS',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#autotoc_md6',1,'']]]
];
