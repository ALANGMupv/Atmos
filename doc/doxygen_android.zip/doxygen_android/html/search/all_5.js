var searchData=
[
  ['facilitar_20el_20acceso_20estructurado_20a_20la_20trama_20recibida_0',['además de campos auxiliares como advFlags, companyID o iBeaconType, para facilitar el acceso estructurado a la trama recibida.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html#autotoc_md17',1,'']]],
  ['fin_20bloque_20para_20cálculo_20del_20índice_20de_20calidad_1',['=== FIN BLOQUE PARA CÁLCULO DEL ÍNDICE DE CALIDAD ===========',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#autotoc_md0',1,'']]],
  ['formato_20texto_20o_20hexadecimal_2',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]],
  ['funciones_20auxiliares_20para_20convertir_20entre_20cadenas_20bytes_20enteros_20y_20uuids_20además_20de_20mostrar_20datos_20en_20formato_20texto_20o_20hexadecimal_3',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]],
  ['funcionesbaseactivity_4',['FuncionesBaseActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html',1,'org::jordi::btlealumnos2021']]]
];
