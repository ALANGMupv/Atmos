var classorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons =
[
    [ "GPSCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons_1_1_g_p_s_callback.html", null ],
    [ "onBeaconDetectado", "classorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons.html#a26ef418d7b43c55e2733f60a98f6c654", null ],
    [ "onBind", "classorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons.html#ae40ab730d0a699bcb388944aa8ed5653", null ],
    [ "onCreate", "classorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons.html#ac5e6576a40c03fb6fcfbd05cdeb7c352", null ]
];