var classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_activity =
[
    [ "onCreate", "classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_activity.html#a593987294e43083c6cc333b092323817", null ]
];