var annotated_dup =
[
    [ "org", null, [
      [ "jordi", null, [
        [ "btlealumnos2021", null, [
          [ "ActividadInicio", "classorg_1_1jordi_1_1btlealumnos2021_1_1_actividad_inicio.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_actividad_inicio" ],
          [ "ActividadSplash", "classorg_1_1jordi_1_1btlealumnos2021_1_1_actividad_splash.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_actividad_splash" ],
          [ "AdaptadorPaginasInicio", "classorg_1_1jordi_1_1btlealumnos2021_1_1_adaptador_paginas_inicio.html", null ],
          [ "AppLifecycleTracker", "classorg_1_1jordi_1_1btlealumnos2021_1_1_app_lifecycle_tracker.html", null ],
          [ "AtmosApp", "classorg_1_1jordi_1_1btlealumnos2021_1_1_atmos_app.html", null ],
          [ "ContaminacionOverlay", "classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay" ],
          [ "EditarPerfilActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_editar_perfil_activity.html", null ],
          [ "EscanearQrActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_escanear_qr_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_escanear_qr_activity" ],
          [ "EstacionesMedidaAPI", "classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i" ],
          [ "EstacionOficial", "classorg_1_1jordi_1_1btlealumnos2021_1_1_estacion_oficial.html", null ],
          [ "FuncionesBaseActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity" ],
          [ "GraficaHelper", "classorg_1_1jordi_1_1btlealumnos2021_1_1_grafica_helper.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_grafica_helper" ],
          [ "Incidencia", "classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencia.html", null ],
          [ "IncidenciasActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_activity" ],
          [ "IncidenciasAdapter", "classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_adapter.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_adapter" ],
          [ "InfoPopupActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_info_popup_activity.html", null ],
          [ "InicioSesionActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_inicio_sesion_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_inicio_sesion_activity" ],
          [ "LogicaFake", "classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake" ],
          [ "MainActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity" ],
          [ "MapasActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_mapas_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_mapas_activity" ],
          [ "MenuActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_menu_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_menu_activity" ],
          [ "NotificacionAtmos", "classorg_1_1jordi_1_1btlealumnos2021_1_1_notificacion_atmos.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_notificacion_atmos" ],
          [ "PaginaInicio", "classorg_1_1jordi_1_1btlealumnos2021_1_1_pagina_inicio.html", null ],
          [ "PerfilActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_perfil_activity.html", null ],
          [ "Preferencias", "classorg_1_1jordi_1_1btlealumnos2021_1_1_preferencias.html", null ],
          [ "PrivacidadActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_privacidad_activity.html", null ],
          [ "RegistroActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_registro_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_registro_activity" ],
          [ "RestablecerContrasenaActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_restablecer_contrasena_activity.html", null ],
          [ "ServicioDeteccionBeacons", "classorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons" ],
          [ "SesionManager", "classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html", null ],
          [ "TramaIBeacon", "classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html", null ],
          [ "UserPageActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_user_page_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_user_page_activity" ],
          [ "Utilidades", "classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html", null ],
          [ "VincularSensorActivity", "classorg_1_1jordi_1_1btlealumnos2021_1_1_vincular_sensor_activity.html", "classorg_1_1jordi_1_1btlealumnos2021_1_1_vincular_sensor_activity" ]
        ] ]
      ] ]
    ] ]
];