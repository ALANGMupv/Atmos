var classorg_1_1jordi_1_1btlealumnos2021_1_1_escanear_qr_activity =
[
    [ "onPause", "classorg_1_1jordi_1_1btlealumnos2021_1_1_escanear_qr_activity.html#ade8a61f6bb4137fe48930ead076f9dc1", null ],
    [ "onRequestPermissionsResult", "classorg_1_1jordi_1_1btlealumnos2021_1_1_escanear_qr_activity.html#aa7104e1fb7e6c5c1f7ae6de109fc90f4", null ],
    [ "onResume", "classorg_1_1jordi_1_1btlealumnos2021_1_1_escanear_qr_activity.html#a80e5e83aea7f50e522fe73c02aadd91e", null ]
];