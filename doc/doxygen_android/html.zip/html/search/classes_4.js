var searchData=
[
  ['funcionesbaseactivity_0',['FuncionesBaseActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html',1,'org::jordi::btlealumnos2021']]]
];
