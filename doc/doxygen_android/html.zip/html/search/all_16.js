var searchData=
[
  ['índice_20de_20calidad_0',['=== FIN BLOQUE PARA CÁLCULO DEL ÍNDICE DE CALIDAD ===========',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#autotoc_md0',1,'']]],
  ['índice_20para_20evitar_20mostrar_20información_20obsoleta_20última_20ciudad_20válida_1',['de índice para evitar mostrar información obsoleta (última ciudad válida).',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_mapas_activity.html#autotoc_md10',1,'']]]
];
