var searchData=
[
  ['gas_0',['RESUMEN USUARIO POR GAS',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#autotoc_md6',1,'']]],
  ['guardarsesion_1',['MÉTODO: guardarSesion',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md12',1,'']]]
];
