var searchData=
[
  ['setonindiceupdatelistener_0',['setOnIndiceUpdateListener',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#aa5cf92d94b43cce97a16db200cfa2b4e',1,'org::jordi::btlealumnos2021::ContaminacionOverlay']]],
  ['setpuntos_1',['setPuntos',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#a773fcad3ff67970c6817db6370a2fb78',1,'org::jordi::btlealumnos2021::ContaminacionOverlay']]],
  ['setupbottomnav_2',['setupBottomNav',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a260f8eba142bd2f33675fac930ae652e',1,'org.jordi.btlealumnos2021.FuncionesBaseActivity.setupBottomNav(int selected)'],['../classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a4213646bda8062a402d21e9846f8b240',1,'org.jordi.btlealumnos2021.FuncionesBaseActivity.setupBottomNav()']]],
  ['setupheader_3',['setupHeader',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a357a26d6537ace7ecfe87125088d219c',1,'org::jordi::btlealumnos2021::FuncionesBaseActivity']]]
];
