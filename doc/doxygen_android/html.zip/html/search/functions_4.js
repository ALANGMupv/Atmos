var searchData=
[
  ['graficahelper_0',['GraficaHelper',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_grafica_helper.html#a220e70ced68b854fc74c009ce39ce557',1,'org::jordi::btlealumnos2021::GraficaHelper']]],
  ['guardarmedicion_1',['guardarMedicion',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a0ca46d20404e428d976e5e85c1ea03aa',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['guardarrecorrido_2',['guardarRecorrido',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a792832ca6d051ed83370070a6291d5df',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['guardarsesion_3',['guardarSesion',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#a40f28dcb89dcee9ae025c8f49e19c008',1,'org::jordi::btlealumnos2021::SesionManager']]]
];
