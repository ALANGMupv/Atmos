var searchData=
[
  ['tramaibeacon_0',['TramaIBeacon',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html',1,'org::jordi::btlealumnos2021']]]
];
