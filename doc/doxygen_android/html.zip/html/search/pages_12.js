var searchData=
[
  ['terminen_0',['ESPERAR A QUE TODAS LAS DESCARGAS TERMINEN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md2',1,'']]],
  ['texto_20o_20hexadecimal_1',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]],
  ['todas_20las_20descargas_20terminen_2',['ESPERAR A QUE TODAS LAS DESCARGAS TERMINEN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md2',1,'']]],
  ['trama_20recibida_3',['además de campos auxiliares como advFlags, companyID o iBeaconType, para facilitar el acceso estructurado a la trama recibida.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html#autotoc_md17',1,'']]],
  ['tramas_20ibeacon_20con_20datos_20de_20co₂_20y_20los_20envía_20al_20servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_4',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]]
];
