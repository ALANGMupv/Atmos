var searchData=
[
  ['vincularplacaservidor_0',['vincularPlacaServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#ad659e33d93bdb652d6b067adc02d96c3',1,'org::jordi::btlealumnos2021::LogicaFake']]]
];
