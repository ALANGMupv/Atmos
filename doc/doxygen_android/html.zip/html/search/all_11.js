var searchData=
[
  ['sensores_20de_20esta_20estación_0',['DESCARGA DEL DETALLE DE SENSORES DE ESTA ESTACIÓN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md1',1,'']]],
  ['serviciodeteccionbeacons_1',['ServicioDeteccionBeacons',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons.html',1,'org::jordi::btlealumnos2021']]],
  ['servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_2',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['sesionmanager_3',['SesionManager',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html',1,'org::jordi::btlealumnos2021']]],
  ['setonindiceupdatelistener_4',['setOnIndiceUpdateListener',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#aa5cf92d94b43cce97a16db200cfa2b4e',1,'org::jordi::btlealumnos2021::ContaminacionOverlay']]],
  ['setpuntos_5',['setPuntos',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_contaminacion_overlay.html#a773fcad3ff67970c6817db6370a2fb78',1,'org::jordi::btlealumnos2021::ContaminacionOverlay']]],
  ['setupbottomnav_6',['setupBottomNav',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a260f8eba142bd2f33675fac930ae652e',1,'org.jordi.btlealumnos2021.FuncionesBaseActivity.setupBottomNav(int selected)'],['../classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a4213646bda8062a402d21e9846f8b240',1,'org.jordi.btlealumnos2021.FuncionesBaseActivity.setupBottomNav()']]],
  ['setupheader_7',['setupHeader',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a357a26d6537ace7ecfe87125088d219c',1,'org::jordi::btlealumnos2021::FuncionesBaseActivity']]],
  ['sharedpreferences_8',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]],
  ['simple_20de_20notificaciones_20leídas_20en_20sharedpreferences_9',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]]
];
