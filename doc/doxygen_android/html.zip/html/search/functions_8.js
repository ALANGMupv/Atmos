var searchData=
[
  ['marcarincidencialeida_0',['marcarIncidenciaLeida',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#ab96c7bea4f2c3b4c7c49a694770ef16a',1,'org::jordi::btlealumnos2021::LogicaFake']]]
];
