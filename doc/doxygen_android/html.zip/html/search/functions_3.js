var searchData=
[
  ['enviarincidencia_0',['enviarIncidencia',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#afa2a5fd8e111f22133a009c1844037eb',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['estadoplacaservidor_1',['estadoPlacaServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a1bb4c87322b59fe133cb84d203ce7a33',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['estadosenalservidor_2',['estadoSenalServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#aa81736e3a13c2583eae9eac9b2e01d07',1,'org::jordi::btlealumnos2021::LogicaFake']]]
];
