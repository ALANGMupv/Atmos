var searchData=
[
  ['userpageactivity_0',['UserPageActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_user_page_activity.html',1,'org::jordi::btlealumnos2021']]],
  ['utilidades_1',['Utilidades',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html',1,'org::jordi::btlealumnos2021']]]
];
