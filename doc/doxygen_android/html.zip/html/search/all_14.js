var searchData=
[
  ['válida_0',['de índice para evitar mostrar información obsoleta (última ciudad válida).',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_mapas_activity.html#autotoc_md10',1,'']]],
  ['vincular_20placa_20a_20usuario_1',['VINCULAR PLACA A USUARIO',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_vincular_placa_callback.html#autotoc_md7',1,'']]],
  ['vincularplacacallback_2',['VincularPlacaCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_vincular_placa_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['vincularplacaservidor_3',['vincularPlacaServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#ad659e33d93bdb652d6b067adc02d96c3',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['vincularsensoractivity_4',['VincularSensorActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_vincular_sensor_activity.html',1,'org::jordi::btlealumnos2021']]]
];
