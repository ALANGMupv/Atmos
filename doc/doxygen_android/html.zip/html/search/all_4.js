var searchData=
[
  ['editarperfil_20y_20otras_20pantallas_0',['Compatibles con EditarPerfil y otras pantallas',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md14',1,'']]],
  ['editarperfilactivity_1',['EditarPerfilActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_editar_perfil_activity.html',1,'org::jordi::btlealumnos2021']]],
  ['el_20acceso_20estructurado_20a_20la_20trama_20recibida_2',['además de campos auxiliares como advFlags, companyID o iBeaconType, para facilitar el acceso estructurado a la trama recibida.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html#autotoc_md17',1,'']]],
  ['en_20formato_20texto_20o_20hexadecimal_3',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]],
  ['en_20sharedpreferences_4',['Persistencia simple de NOTIFICACIONES LEÍDAS en SharedPreferences',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_notificaciones_activity.html#autotoc_md11',1,'']]],
  ['enteros_20y_20uuids_20además_20de_20mostrar_20datos_20en_20formato_20texto_20o_20hexadecimal_5',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]],
  ['entre_20cadenas_20bytes_20enteros_20y_20uuids_20además_20de_20mostrar_20datos_20en_20formato_20texto_20o_20hexadecimal_6',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]],
  ['envía_20al_20servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_7',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['enviarincidencia_8',['enviarIncidencia',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#afa2a5fd8e111f22133a009c1844037eb',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['enviarincidenciacallback_9',['EnviarIncidenciaCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_enviar_incidencia_callback.html',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['escanearqractivity_10',['EscanearQrActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_escanear_qr_activity.html',1,'org::jordi::btlealumnos2021']]],
  ['esperar_20a_20que_20todas_20las_20descargas_20terminen_11',['ESPERAR A QUE TODAS LAS DESCARGAS TERMINEN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md2',1,'']]],
  ['esta_20estación_12',['DESCARGA DEL DETALLE DE SENSORES DE ESTA ESTACIÓN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md1',1,'']]],
  ['estación_13',['DESCARGA DEL DETALLE DE SENSORES DE ESTA ESTACIÓN',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#autotoc_md1',1,'']]],
  ['estacionescallback_14',['EstacionesCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i_1_1_estaciones_callback.html',1,'org::jordi::btlealumnos2021::EstacionesMedidaAPI']]],
  ['estacionesmedidaapi_15',['EstacionesMedidaAPI',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html',1,'org::jordi::btlealumnos2021']]],
  ['estacionoficial_16',['EstacionOficial',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_estacion_oficial.html',1,'org::jordi::btlealumnos2021']]],
  ['estadoplacaservidor_17',['estadoPlacaServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a1bb4c87322b59fe133cb84d203ce7a33',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['estadosenalservidor_18',['estadoSenalServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#aa81736e3a13c2583eae9eac9b2e01d07',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['estructurado_20a_20la_20trama_20recibida_19',['además de campos auxiliares como advFlags, companyID o iBeaconType, para facilitar el acceso estructurado a la trama recibida.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_trama_i_beacon.html#autotoc_md17',1,'']]],
  ['evitar_20mostrar_20información_20obsoleta_20última_20ciudad_20válida_20',['de índice para evitar mostrar información obsoleta (última ciudad válida).',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_mapas_activity.html#autotoc_md10',1,'']]]
];
