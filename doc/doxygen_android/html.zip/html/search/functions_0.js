var searchData=
[
  ['actualizarestadoplaca_0',['actualizarEstadoPlaca',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#aac2d0677250d11371ef7a7e390b430d9',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['actualizarusuarioservidor_1',['actualizarUsuarioServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a16ed90ebdc628e7c166675b36ac6fbf4',1,'org::jordi::btlealumnos2021::LogicaFake']]]
];
