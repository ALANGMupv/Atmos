var searchData=
[
  ['incidencia_0',['Incidencia',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencia.html',1,'org::jordi::btlealumnos2021']]],
  ['incidenciasactivity_1',['IncidenciasActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_activity.html',1,'org::jordi::btlealumnos2021']]],
  ['incidenciasadapter_2',['IncidenciasAdapter',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_incidencias_adapter.html',1,'org::jordi::btlealumnos2021']]],
  ['infopopupactivity_3',['InfoPopupActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_info_popup_activity.html',1,'org::jordi::btlealumnos2021']]],
  ['iniciosesionactivity_4',['InicioSesionActivity',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_inicio_sesion_activity.html',1,'org::jordi::btlealumnos2021']]]
];
