var searchData=
[
  ['y_20botones_20de_20la_20interfaz_0',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['y_20los_20envía_20al_20servidor_20además_20de_20manejar_20permisos_20y_20botones_20de_20la_20interfaz_1',['muestra información de dispositivos o busca uno concreto, parsea tramas iBeacon con datos de CO₂ y los envía al servidor, además de manejar permisos y botones de la interfaz.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#autotoc_md9',1,'']]],
  ['y_20otras_20pantallas_2',['Compatibles con EditarPerfil y otras pantallas',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md14',1,'']]],
  ['y_20uuids_20además_20de_20mostrar_20datos_20en_20formato_20texto_20o_20hexadecimal_3',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]]
];
