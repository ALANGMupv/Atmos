var searchData=
[
  ['habilitartogglecontrasena_0',['habilitarToggleContrasena',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_funciones_base_activity.html#a431fc555880931154810368e98febd2e',1,'org::jordi::btlealumnos2021::FuncionesBaseActivity']]],
  ['haysesionactiva_1',['haySesionActiva',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#a082a21393f62b983d23ed79498fb52d9',1,'org.jordi.btlealumnos2021.SesionManager.haySesionActiva()'],['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md15',1,'MÉTODO: haySesionActiva']]],
  ['hexadecimal_2',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]]
];
