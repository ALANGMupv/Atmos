var searchData=
[
  ['recargargrafica_0',['recargarGrafica',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_grafica_helper.html#a7b839054d6569a986bb03c677953b893',1,'org::jordi::btlealumnos2021::GraficaHelper']]],
  ['registroservidor_1',['registroServidor',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#a0df835a1089b4d8db20d1e064f1bc79d',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['resumen7dias_2',['resumen7Dias',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#aaa7a7a54818cf8fb7fc715f46f3a275c',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['resumen8horas_3',['resumen8Horas',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#ab7117d62dacc036e37708f2dfaae00ee',1,'org::jordi::btlealumnos2021::LogicaFake']]],
  ['resumenusuarioporgas_4',['resumenUsuarioPorGas',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake.html#ae238d07376a64e4c52fba4161f405585',1,'org::jordi::btlealumnos2021::LogicaFake']]]
];
