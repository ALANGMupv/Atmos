var searchData=
[
  ['gpscallback_0',['GPSCallback',['../interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_servicio_deteccion_beacons_1_1_g_p_s_callback.html',1,'org::jordi::btlealumnos2021::ServicioDeteccionBeacons']]],
  ['graficahelper_1',['GraficaHelper',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_grafica_helper.html',1,'org::jordi::btlealumnos2021']]]
];
