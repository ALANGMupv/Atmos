var searchData=
[
  ['haysesionactiva_0',['MÉTODO: haySesionActiva',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_sesion_manager.html#autotoc_md15',1,'']]],
  ['hexadecimal_1',['Utilidades.java: clase con funciones auxiliares para convertir entre cadenas, bytes, enteros y UUIDs, además de mostrar datos en formato texto o hexadecimal.',['../classorg_1_1jordi_1_1btlealumnos2021_1_1_utilidades.html#autotoc_md18',1,'']]]
];
