var classorg_1_1jordi_1_1btlealumnos2021_1_1_actividad_splash =
[
    [ "onCreate", "classorg_1_1jordi_1_1btlealumnos2021_1_1_actividad_splash.html#a622a9afc141ff81e07834b90d8d08c37", null ]
];