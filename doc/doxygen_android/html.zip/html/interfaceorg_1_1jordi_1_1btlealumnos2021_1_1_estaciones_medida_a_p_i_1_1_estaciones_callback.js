var interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i_1_1_estaciones_callback =
[
    [ "onResult", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i_1_1_estaciones_callback.html#a2491330410fdc8612b2eae48bfd0a926", null ]
];