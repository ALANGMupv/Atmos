var interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_callback_recorrido =
[
    [ "onRespuesta", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_logica_fake_1_1_callback_recorrido.html#aa17e29ef6d193be15ae2f676795ce846", null ]
];