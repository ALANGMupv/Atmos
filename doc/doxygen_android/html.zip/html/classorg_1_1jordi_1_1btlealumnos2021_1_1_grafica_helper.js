var classorg_1_1jordi_1_1btlealumnos2021_1_1_grafica_helper =
[
    [ "GraficaHelper", "classorg_1_1jordi_1_1btlealumnos2021_1_1_grafica_helper.html#a220e70ced68b854fc74c009ce39ce557", null ],
    [ "recargarGrafica", "classorg_1_1jordi_1_1btlealumnos2021_1_1_grafica_helper.html#a7b839054d6569a986bb03c677953b893", null ]
];