var classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i =
[
    [ "EstacionesCallback", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i_1_1_estaciones_callback.html", "interfaceorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i_1_1_estaciones_callback" ],
    [ "obtenerEstacionesOficiales", "classorg_1_1jordi_1_1btlealumnos2021_1_1_estaciones_medida_a_p_i.html#a07b7d2f2ae373dec621d7e5e16157651", null ]
];