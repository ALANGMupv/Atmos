var classorg_1_1jordi_1_1btlealumnos2021_1_1_menu_activity =
[
    [ "onCreate", "classorg_1_1jordi_1_1btlealumnos2021_1_1_menu_activity.html#a02059433d05d668d243579a23a4b8bae", null ],
    [ "onResume", "classorg_1_1jordi_1_1btlealumnos2021_1_1_menu_activity.html#a17104f86e7c71ba27131d50e506a2140", null ]
];