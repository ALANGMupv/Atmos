var classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity =
[
    [ "onRequestPermissionsResult", "classorg_1_1jordi_1_1btlealumnos2021_1_1_main_activity.html#a28d67ac985c36babb8a0bfca6db93a5c", null ]
];